﻿
using System;
namespace College.App_Code
{
    class Common
    {
        public static bool command;
        public static double fine;
        public static string adminId;
        public static string des;
        public static string role;
        public static string month;
        public static int year;
        public static int batchCode;
        public static int classCode;

        public static DateTime date;

    }
}
