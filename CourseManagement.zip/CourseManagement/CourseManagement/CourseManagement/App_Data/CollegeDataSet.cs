﻿namespace College.App_Data {
    
    
    public partial class CollegeDataSet {
    }
}
namespace College.App_Data {
    
    
    public partial class CollegeDataSet {
    }
}
