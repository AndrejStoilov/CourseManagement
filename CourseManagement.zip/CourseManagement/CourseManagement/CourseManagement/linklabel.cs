﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace College
{
    public partial class linklabel : Component
    {
        public linklabel()
        {
            InitializeComponent();
        }

        public linklabel(IContainer container)
        {
            container.Add(this);

            InitializeComponent();
        }
    }
}
