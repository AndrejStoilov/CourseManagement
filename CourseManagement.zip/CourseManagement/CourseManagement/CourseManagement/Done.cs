﻿using System;
using System.Windows.Forms;

namespace College
{
    public partial class Done : Form
    {
        public Done()
        {
            InitializeComponent();
        }

        private void Done_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
